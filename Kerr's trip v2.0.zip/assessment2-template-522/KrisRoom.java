import greenfoot.*;  // imports Actor, World, Greenfoot, GreenfootImage

/**
 * Kerr is an Alien who crossed into a palace on Planet A. He walked 
 * into a Kris’s room in an accident. In the room of the palace, he 
 * found three monsters named Kris. If he meets a monster, he will 
 * faint. Kerr needs to avoid the monster Kris and collect gold coins, 
 * leave the room, and finally escape the palace. Gold coins can be 
 * upgraded to make Kerr stronger and armed. Version 1.0 is just you 
 * control player Kerr to move randomly in Kris’s room. You just press 
 * ‘RUN’ or ‘ACT’ to start this game. This game is built for the teens 
 * The character Alien Kerr image is from the template. The character 
 * Monster Kris image and background image are from the Internet. 
 * Backgroung image URL: 
 * https://www.zcool.com.cn/work/ZMjYwNDU0NDg=.html
 * 
 * @author Zidong Peng & 202100408064
 * @version 1.1 19/11/2022
 */

public class KrisRoom extends World
{
    /**
     * Create Kris's room. The room has a size of 900x600 cells, 
     * where every cell is just 1 pixel.
     */
    public KrisRoom()
    {
        super(900, 600, 1);
        createPlayerKerr();
        createMonsterKris();
        createCoin();
        display();
        score = 0;
        showText("The First Level", 475, 25);
        }
    
    /**
     * Initialize the player Kerr in the center of the room.
     */    
    
    public void createPlayerKerr()
    {
        //0.5 is a double type, which needs to be cast to int type.
        int x = (int) (getWidth() * 0.5);
        int y = (int) (getHeight() * 0.5);
        PlayerKerr playerKerr = new PlayerKerr();
        addObject(playerKerr,x,y);
        }
    
    /**
     * Create 3 Monsters in random location which name is Kris in the room.
     */
    public void createMonsterKris()
    {
        for (int i = 0;i < 3;i++)
        {
            int a = Greenfoot.getRandomNumber(700);
            int b = Greenfoot.getRandomNumber(400);
            addObject(new MonsterKris(),a,b);
        }
    }
    
    /**
     * Generate five gold coins randomly.
     */
    public void createCoin()
    {
        for(int i = 0;i < 5;i++)
        {
            int d = Greenfoot.getRandomNumber(700);
            int e = Greenfoot.getRandomNumber(400);
            Coin coin = new Coin();
            addObject(coin,d,e);
        }
    }
    
    private int score;
    /**
     * Method addScore
     *
     */
    public void addScore()
    {
        score = score + 20;
        showText("Score:" + score, 80, 25);
    }
    
    private int time = 20;
    
    private double count = 60;
    
    /**
     * Method act
     *
     */
    public void act() 
    {
        if(time == 0)
        {
            return;
        }
         
        if(counter())
        {
            time--;
            count = 60;
        }
        display();
        if (score == 100)
        {
            World balcony = new Balcony(score);
            Greenfoot.setWorld(balcony);
        }
    }    
     
    /**
     * Method counter
     *
     * @return The return value
     */
    private boolean counter()
    {
        if(count > 0)
        {
            count = count - 1.5;
        }
        return count == 0;
    }
     
    /**
     * Method display
     *
     */
    private void display()
    {
        showText("Timer:" + time,800,500);
        //If time out, game over.
        if (time == 0)
        {
            Greenfoot.stop();
        }
    }
     
    /**
     * Method setTime
     *
     */
    public void setTime()
    {
        time = 20;
    }
     
    /**
     * Method isTimeUp
     *
     * @return The time value
     */
    public boolean isTimeUp()
    {
        return time == 0;
    }
    
    /**
     * Method getTime
     *
     * @return The time value
     */
    public long getTime()
    {
        return time;
    }
}
    
    

    
    

    