import greenfoot.*;  // World, Actor, GreenfootImage, and Greenfoot

/**
 * Player Kerr. Kerr moves randomly until he hits the edge of the world, at
 * which point it turns randomly. If Kerr meet a monster Kris, he will get
 * vertigo effect in a short time. The image is from the template.
 * 
 * @author Zidong Peng & 202100408064
 * @version 1.0 11/11/2022
 */

public class PlayerKerr extends Actor
{          
    GreenfootImage image1;
    GreenfootImage image2;
    /** 
     * Act - contains the player actions. This method is called whenever
     *  the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        /*Kerr can collect coin.*/
        coinEaten();
        /*Use keyboard to control Kerr to move.*/
        checkKeys();
        
        moveUpOrDown();
        
        ToTheEnd();
    }
    
    private int coinsCollected;  //Declare a varible to count coins.
    
    /**
     * PlayerKerr Constuctor
     */
    public PlayerKerr()
    {
        coinsCollected = 0;
        image1 = new GreenfootImage("birdwithhat.png");
        image2 = new GreenfootImage("bird2.png");
    }
    
    /**
     * When player touch MonsterKris, the vertigo effect in player.
     */
    public void touchMonster()
    {
        if (isTouching(MonsterKris.class))
        {
            turn(22);
        }
    }
    
    /**
     * When Kerr touch the coin, he will eat the coin.
     */
    public void coinEaten()
    {
        if (isTouching(Coin.class))
        {
            removeTouching(Coin.class);
            coinsCollected = coinsCollected + 1;
            KrisRoom krisRoom = (KrisRoom)getWorld();
            krisRoom.addScore();
        }
    }
    
    /**
     * Return coinsCollected value.
     */
    public int getCoinsCollected()
    {
        return coinsCollected;
    }
    
    /**
     * Method checkKeys.
     * Use "up", "down", "right", "left" to control.
     */
    public void checkKeys() 
    {
        if (Greenfoot.isKeyDown("up"))
        {
            setLocation(getX(), getY()-5);
        }        
        if (Greenfoot.isKeyDown("down"))
        {
            setLocation(getX(), getY()+5);
        }
        if (Greenfoot.isKeyDown("left"))
        {
            setLocation(getX()-5, getY());
            setImage(image2);
        }
        if (Greenfoot.isKeyDown("right"))
        {
            setLocation(getX()+5, getY());
            setImage(image1);
        }
        if (Greenfoot.isKeyDown("space"))
        {
            getWorld().addObject(new Bullet(), getX(), getY());
        }
    }
    
    /**
     * Method moveUpOrDown
     *
     */
    public void moveUpOrDown()
    {
        if (Greenfoot.isKeyDown("up"))
        {
            if (getOneObjectAtOffset(0,-35,Cactus.class) == null)
            {
                setLocation(getX(),getY()-5);
            }
            else
            {
                setLocation(getX(),getY()+10);
            }
        }
    }
    
    /**
     * Method ToTheEnd
     *
     */
    public void ToTheEnd()
    {
        if (isTouching(Exit.class))
        {
            World end = new End();
            Greenfoot.setWorld(end);
        }
    }
}
