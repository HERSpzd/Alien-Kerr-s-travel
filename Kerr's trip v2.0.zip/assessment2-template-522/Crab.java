import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Crab here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Crab extends Actor
{
    GreenfootImage image1;
    GreenfootImage image2;
    
    /**
     * Act - do whatever the Crab wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        animate();
        /*Random move at the adge of the world*/
        atEdge();
        /*Kris can move randomly in the world*/
        randomMove();
        
        gameOver();
    }
    
    /**
     * Crab Constructor
     *
     */
    public Crab()
    {
        image1 = new GreenfootImage("crab.png");
        image2 = new GreenfootImage("crab2.png");
    }
    
    public String name;
    
    /**
     * Crab Constructor
     *
     * @param name A parameter
     */
    Crab(String name)
    {
        this.name = "abc";
        
    }
    
    /**
     * Method animate
     *
     */
    public void animate()
    {
        if (getImage() == image1)
        {
            setImage(image2);
        }
        else
        {
            setImage(image1);
        }
    }
    
    /**
     * Method atEdge
     * Crab turn when it meet the world edge.
     *
     */
    public void atEdge()
    {
        int a = Greenfoot.getRandomNumber(360);
        if (isAtEdge())
        {
            turn(a);  //Get random rotation degree.
        }
        
    }
    
    /**
     * Method randomMove
     * When the 'Act' or 'Run' button gets pressed, the player can random
     * move in the world.
     *
     */
    public void randomMove()
    {
        int b = Greenfoot.getRandomNumber(5);  //Get random rotation degree.
        move(5);
        turn(b);  
    }
    
    /**
     * Method gameOver
     *
     */
    public void gameOver()
    {
        if (isTouching(PlayerKerr.class))
        {
            Greenfoot.stop();
        }
    }
}
