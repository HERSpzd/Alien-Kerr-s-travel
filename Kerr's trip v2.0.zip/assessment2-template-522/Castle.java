import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Castle class. 
 * The image is from the Internet.
 * URL: http://www.win4000.com/wallpaper_detail_49315.html
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Castle extends World
{

    /**
     * Constructor for objects of class Castle.
     * 
     */
    public Castle()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 600, 1);
        
        createTitle();
        
        createSubtitle();
        
        createName();
    }
    
    /**
     * Method createTitle
     *
     */
    public void createTitle()
    {
        Title title = new Title();
        addObject(title,486,153);
    }
    
    /**
     * Method createSubtitle
     *
     */
    public void createSubtitle()
    {
        Subtitle subtitle = new Subtitle();
        addObject(subtitle,439,479);
    }
    
    public void createName()
    {
        addObject(new Name(),469,329);
    }
    
    /**
     * Method act
     *
     */
    public void act()
    {
        if (Greenfoot.isKeyDown("w"))
        {
            World krisRoom = new KrisRoom();
            Greenfoot.setWorld(krisRoom);
        }
    }
}
