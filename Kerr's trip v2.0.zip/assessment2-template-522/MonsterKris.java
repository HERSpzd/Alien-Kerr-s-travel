import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot and MouseInfo

/**
 * Monster Kris. A MonsterKris moves forward until it hits the edge of the world, at
 * which point it turns right. 
 * The image is from the Internet.
 * URL: http://www.win4000.com/wallpaper_detail_49315.html
 * 
 * @author Zidong Peng 
 * @version 1.0 11/11/2022
 */
public class MonsterKris extends Actor 
{
    /**
     * Act - do whatever the MonsterKris wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        /*Random move at the adge of the world*/
        atEdge();
        /*Kris can move randomly in the world*/
        randomMove();
        
        gameOver();
        
    }
    
    /**
     * Method atEdge
     * Kris turn when it meet the world edge.
     *
     */
    public void atEdge()
    {
        int a = Greenfoot.getRandomNumber(360);
        if (isAtEdge())
        {
            turn(a);  //Get random rotation degree.
        }
        
    }
    
    /**
     * Method randomMove
     * When the 'Act' or 'Run' button gets pressed, the player can random
     * move in the world.
     *
     */
    public void randomMove()
    {
        int b = Greenfoot.getRandomNumber(5);  //Get random rotation degree.
        move(5);
        turn(b);  
    }
    
    /**
     * Method gameOver
     *
     */
    public void gameOver()
    {
        if (isTouching(PlayerKerr.class))
        {
            Greenfoot.stop();
        }
    }
    
}