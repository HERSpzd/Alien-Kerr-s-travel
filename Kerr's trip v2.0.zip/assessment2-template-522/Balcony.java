import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Balcony class.
 * The image is from the Internet.
 * URL: https://www.zcool.com.cn/work/ZMjYwNDU0NDg=.html
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Balcony extends World
{

    /**
     * Constructor for objects of class Balcony.
     * 
     */
    public Balcony(int s)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 600, 1);
        createKerr();
        craeteCactus();
        createLexus();
        createCrab();
        createExit();
        showText("Score:" + s, 80, 25);
        showText("The Second Level", 475, 25);        
    }
    
    /**
     * Method createKerr
     *
     */
    public void createKerr()
    {
        PlayerKerr playerKerr = new PlayerKerr();
        addObject(playerKerr,40,360);
    }
    
    /**
     * Method craeteCactus
     *
     */
    public void craeteCactus()
    {
        int counter = 0;
        while (counter < 90)
        {
            addObject(new Cactus(), counter * 40, 260);
            counter++;
        }
    }
    
    /**
     * Method createLexus
     *
     */
    public void createLexus()
    {
        addObject(new Lexus(),799,229);
    }
    
    /**
     * Method createExit
     *
     */
    public void createExit()
    {
        addObject(new Exit(),839,347);
    }
    
    /**
     * Method createCrab
     *
     */
    public void createCrab()
    {
        Crab crab = new Crab();
        addObject(crab, 352, 203);
        int randomTime = 0;
        for(int i = 0;i<10;i++)
        {    
            randomTime = Greenfoot.getRandomNumber(10);
        }
        if (randomTime < 5)
        {
            addObject(crab, 352, 203);
        }
    }
}
