import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class End here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class End extends World
{
    public static boolean isPaused = true;
    /**
     * Constructor for objects of class End.
     * 
     */
    public End()
    {    
        // Create a new world with 900x600 cells with a cell size of 1x1 pixels.
        super(900, 600, 1);
        addObject(new EndTitle(),450,90);
        addObject(new Restart(),455,376);
        showText("Score:100",80,25);
        
        
    }
    
    /**
     * Method act
     *
     */
    public void act()
    {
        if (!isPaused)
        {
            World castle = new Castle();
            Greenfoot.setWorld(castle);
            isPaused = true;
        }
        else if (Greenfoot.isKeyDown("space"))
        {
            World castle = new Castle();
            Greenfoot.setWorld(castle);
            isPaused = true;
        }
    }
}

