import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Coin. Kerr can collect coins to upgrade.
 * The image is from 
 * URL: http://www1.photophoto.cn/tupian/jinbishejitupian-16946764.html
 * 
 * @author Zidong Peng 202100408064 
 * @version 1.1 19/11/2022
 */
public class Coin extends Actor
{
    /**
     * Act - do whatever the coin wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        
    }
    
}
