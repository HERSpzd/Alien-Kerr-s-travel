import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet class.
 * The image is from the Internet.
 * URL: https://pan.baidu.com/s/1UDuYDy1CkFg5sxBa9BLAqA
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setLocation(getX() + 20,getY());
        if (getX() >= getWorld().getWidth() - 1)
        {
            getWorld().removeObject(this);
        }
    }
    
    /**
     * Bullet Constructor
     *
     */
    public Bullet()
    {
        GreenfootImage bullet = new GreenfootImage(20,5);
        bullet.setColor(Color.RED);
        bullet.fillOval(1,1,6,5);
        bullet.setColor(Color.YELLOW);
        bullet.fillRect(7,1,20,5);
        setImage(bullet);
    }
    
   
}
